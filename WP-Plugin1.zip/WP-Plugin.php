<?php
/** 
* Plugin Name: Hello Web Project
* Description: A standard plugin for printing "Hello there!" on your website.
* Author: Daan Maat
*/

//Simple print for "Hello There"
print "Hello there";