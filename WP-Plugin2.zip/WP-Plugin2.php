<?php
/** 
* Plugin Name: Cute cat Project
* Description: A standard plugin for showing a cute cat picture on your web page.
* Author: Daan Maat
*/

//Simple code for showing the cat picture
echo "<img src='https://dapzw.websmidconcept.nl/wp-content/uploads/2023/04/Geen-foto-gevonden-396x352.jpg'>";